Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Threading

Public Class Server
    Private Shared clients As New Dictionary(Of String, TcpClient)
    Private Shared serverSocket As TcpListener

    Public Shared Sub Main()
        Dim port As Integer = 23569
        serverSocket = New TcpListener(IPAddress.Any, port)
        serverSocket.Start()

        Console.WriteLine("Servidor de chat en ejecuci�n en el puerto " & port)

        While True
            Dim client As TcpClient = serverSocket.AcceptTcpClient()
            Dim clientThread As New Thread(Sub() HandleClient(client))
            clientThread.Start()
        End While
    End Sub

    Private Shared Sub HandleClient(client As TcpClient)
        Dim clientStream As NetworkStream = client.GetStream()
        Dim reader As New StreamReader(clientStream)
        Dim writer As New StreamWriter(clientStream)
        Dim username As String = ""

        Try
            SendMessage(writer, "Ingresa tu nombre de usuario: ")
            username = reader.ReadLine()

            SyncLock clients
                While clients.ContainsKey(username)
                    SendMessage(writer, "El nombre de usuario ya est� en uso. Ingresa otro: ")
                    username = reader.ReadLine()
                End While
                clients.Add(username, client)
            End SyncLock

            SendMessage(writer, "Bienvenido al chat, " & username & "!")
            BroadcastMessage(username & " se ha unido al chat.")

            Dim message As String = ""
            While True
                Try
                    message = reader.ReadLine()
                    If message.ToLower() = "/exit" Then
                        Exit While
                    End If

                    BroadcastMessage(username & ": " & message)
                Catch ex As Exception
                    Exit While
                End Try
            End While
        Catch
            ' Manejar excepciones de forma adecuada si el cliente se desconecta
        Finally
            SyncLock clients
                clients.Remove(username)
            End SyncLock
            BroadcastMessage(username & " ha abandonado el chat.")
            client.Close()
        End Try
    End Sub

    Private Shared Sub SendMessage(writer As StreamWriter, message As String)
        writer.WriteLine(message)
        writer.Flush()
    End Sub

    Private Shared Sub BroadcastMessage(message As String)
        Console.WriteLine(message)
        SyncLock clients
            For Each client In clients.Values
                Dim clientWriter As New StreamWriter(client.GetStream())
                SendMessage(clientWriter, message)
            Next
        End SyncLock
    End Sub
End Class
