Imports System.IO
Imports System.Net.Sockets
Imports System.Text
Imports System.Threading

Public Class Client
    Public Shared Sub Main()
        Dim serverIP As String = " 10.0.0.32"
        Dim serverPort As Integer = 23569
        Dim client As New TcpClient()

        Try
            client.Connect(serverIP, serverPort)
            Dim clientStream As NetworkStream = client.GetStream()
            Dim reader As New StreamReader(clientStream)
            Dim writer As New StreamWriter(clientStream)
            writer.AutoFlush = True

            Dim msj As String = ""

            Dim receiveThread As New Thread(
                Sub()
                    While True
                        Try
                            msj = reader.ReadLine()
                            Console.WriteLine(msj)
                        Catch ex As Exception
                            Exit While
                        End Try
                    End While
                End Sub
            )
            receiveThread.Start()

            Dim message As String = ""
            While True
                message = Console.ReadLine()
                SendMessage(writer, message)
            End While
        Catch ex As Exception
            Console.WriteLine("Error: " & ex.Message)
        End Try
    End Sub

    Private Shared Sub SendMessage(writer As StreamWriter, message As String)
        writer.WriteLine(message)
    End Sub
End Class
