import java.io.*;
import java.net.*;
import java.util.*;

/*
* Clase Servidor esta arrancará el servicio del chat
*/
public class Server {
	//Se define un puerto para la conexión 
    private static final int PORT = 12345;
	//Se crea un Map que tendrá los clientes del chat y lo que introducen en el teclado
    private static final Map<String, PrintWriter> clients = new HashMap<>();

    public static void main(String[] args) {
		//Se inicia el socket con el servidor que se asignó
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
			//Se muestra al usuario que el servidor se ejecutó correctamente en el puerto asignado
            System.out.println("Servidor de chat en ejecución en el puerto " + PORT);
			
			//Este cliclo estará en espera de una nueva conexión y si existe una se acepta y se incia la comunicación con el cliente
            while (true) {
				//Cuando se detecta una nueva conexión, se crea una instancia de ClientHandler para manejar esa conexión.
                new ClientHandler(serverSocket.accept()).start();
            }
        } catch (IOException e) {
			//muestra los errores en caso de presentarse
            e.printStackTrace();
        }
    }

	/*
	* Esta clase llevará el registro de clientes y enviará la información que introduzcan los clientes entre si
	*/
    private static class ClientHandler extends Thread {
		//Socket para la conexión con un cliente
        private Socket socket;
		//Flujo de salida para enviar mensajes al cliente
        private PrintWriter out;
		//Nombre de usuario del cliente
        private String username;
		
		//Crea un socket por cada usuario
        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
			//Este método se ejecuta cuando se inicia el hilo
            try (
				//Lee datos del cliente
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				//Envía datos al cliente
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true)
            ) {
				//
                this.out = out;
				//Se le pide al cliente que ingrese un nombre de usuario
                out.println("Ingresa tu nombre de usuario: ");
                username = in.readLine();
				//Se asegura de que el nombre de usuario no esté vacío o en uso
                while (username == null || username.isEmpty() || clients.containsKey(username)) {
                    out.println("El nombre de usuario no es válido o ya está en uso. Ingresa otro: ");
                    username = in.readLine();
                }
				//Registrar cliente
                synchronized (clients) {
                    clients.put(username, out);
                }
				//Mensaje de bienvenida al cliente
                out.println("Bienvenido al chat, " + username + "!");
				//Transmisión de Mensaje a los demás clientes
                broadcast(username + " se ha unido al chat.");

                String message;
				/*El servidor entra en un bucle para recibir y transmitir mensajes del cliente. 
				* Si el cliente envía la palabra "exit", el bucle se rompe y el hilo se cierra
				*/
                while ((message = in.readLine()) != null) {
                    if ("exit".equals(message)) {
                        break;
                    }
                    broadcast(username + ": " + message);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
				// Código para manejar cierre de conexión y limpieza
                if (username != null) {
					//se cierra la sesión del cliente
                    synchronized (clients) {
                        clients.remove(username);
                    }
					//Se da aviso a los clientes que el usuario abandonó el chat
                    broadcast(username + " ha abandonado el chat.");
                }
                try {
					//Se finaliza el socket
                    socket.close();
                } catch (IOException e) {
					//Si hay errores se muestran en pantalla
                    e.printStackTrace();
                }
            }
        }
    }

	//Este método envía un mensaje a todos los clientes conectados.
    private static void broadcast(String message) {
        synchronized (clients) {
            for (PrintWriter client : clients.values()) {
                client.println(message);
            }
        }
    }
}
