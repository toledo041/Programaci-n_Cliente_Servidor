//Importa las clases necesarias para manejar entrada/salida y operaciones de red.
import java.io.*;
import java.net.*;

public class Client {
	//Dirección IP del servidor al que se conectará el cliente (en este caso, localhost)
    private static final String SERVER_IP = "127.0.0.1";
	//Puerto del servidor al que se conectará el cliente
    private static final int SERVER_PORT = 12345;

    public static void main(String[] args) {
		/*Se crea un socket y se establece una conexión con el servidor. 
		* Se utilizan flujos de entrada/salida para comunicarse con el servidor y leer la entrada 
		* del usuario desde la consola.
		*/
        try (Socket socket = new Socket(SERVER_IP, SERVER_PORT);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in))) {
			
			//Mensaje de Conexión
            System.out.println("Conectado al servidor de chat.");
	
			/*
			* Se crea un hilo (receiveThread) que escucha los mensajes del servidor y los imprime en 
			* la consola del cliente. Esto permite que el cliente reciba mensajes del servidor mientras 
			* sigue siendo capaz de enviar mensajes.
			*/
            Thread receiveThread = new Thread(() -> {
                String message;
                try {
                    while ((message = in.readLine()) != null) {
                        System.out.println(message);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            receiveThread.start();

			/*
			* Se le pide al usuario que ingrese un nombre de usuario y se envía al servidor. 
			* Se utiliza un bucle para asegurarse de que el nombre de usuario no esté vacío.
			*/
            String username;
            do {
                System.out.print("Ingresa tu nombre de usuario: ");
                username = consoleInput.readLine();
                out.println(username);
            } while (username == null || username.isEmpty());

            String message;
			/*
			* Se entra en un bucle donde el cliente puede ingresar mensajes desde la consola 
			y enviarlos al servidor. Si el cliente ingresa "exit", el bucle se rompe y el programa se cierra
			*/
            while (true) {
                message = consoleInput.readLine();
                out.println(message);
                if ("exit".equals(message)) {
                    break;
                }
            }
        } catch (IOException e) {
			//Cualquier excepción de E/S (entrada/salida) se imprime en la consola.
            e.printStackTrace();
        }
    }
}
