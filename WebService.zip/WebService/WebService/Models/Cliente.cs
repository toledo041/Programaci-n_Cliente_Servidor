﻿namespace WebService.Models
{
    public class Cliente
    {
        public string id { get; set; }
        public string nombre { get; set; }

        public string edad { get; set;}

        public string correo { get; set; }
    }
}
 