﻿using Microsoft.AspNetCore.Mvc;
using WebService.Models;

namespace WebService
{
    [ApiController]
    [Route("cliente")]
    public class ClienteController : ControllerBase
    {
        [HttpGet]
        [Route("listar")]
        public dynamic listarCliente(string nombre)
        {
            /*List<Cliente> clintes = new List<Cliente> { 
                new Cliente
                {
                    id = "1",
                    nombre = "Ismael Aguirre",
                    correo = "isma@gmail.com",
                    edad = "19"
                },
                new Cliente
                {
                    id = "2",
                    nombre = "Alan Chavez",
                    correo = "alan@gmail.com",
                    edad = "21"
                }
            };*/
            return "Hola "+nombre+" gracias por usar este servicio.";
        }
    }
}
