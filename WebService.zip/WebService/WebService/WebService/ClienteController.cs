﻿using Microsoft.AspNetCore.Mvc;
using WebService.Models;

namespace WebService
{
    [ApiController]
    [Route("cliente")]
    public class ClienteController : ControllerBase
    {
        [HttpGet]
        [Route("listar")]
        public dynamic listarCliente(string nombre)
        {
            
            return "Hola "+nombre+" gracias por usar este servicio.";
        }
    }
}
