﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        using (HttpClient client = new HttpClient())
        {
            //se pide al usuario su nombre
            Console.Write("Ingrese su nombre: ");
            //se lee lo tecleado al dar enter
            string nombre = Console.ReadLine();

            //Esta es la ruta del servicio que se va a consultar
            //NOTA: el 
            string serviceUrl = "https://localhost:7113/cliente/listar?nombre=" + nombre;
            //se lee lo devuelto por el servidor
            HttpResponseMessage response = await client.GetAsync(serviceUrl);

            if (response.IsSuccessStatusCode)
            {
                string result = await response.Content.ReadAsStringAsync();
                Console.WriteLine(result);
                Console.WriteLine("Presiona Enter para salir...");
                   Console.ReadLine();
            }
            else
            {
                Console.WriteLine($"Error: {response.StatusCode}");
            }
        }
    }
}