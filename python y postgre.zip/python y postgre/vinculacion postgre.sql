-- Database: Vinculation

-- DROP DATABASE IF EXISTS "Vinculation";

CREATE DATABASE "Vinculation"
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'Spanish_Mexico.1252'
    LC_CTYPE = 'Spanish_Mexico.1252'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;


CREATE TABLE "User"
(   
	 "idUser" SERIAL PRIMARY KEY,
	 "name" varchar(50) NOT NULL,
	 "password" varchar(50) NOT NULL,
	 "email" varchar(50) NOT NULL,
	 "status" boolean NOT NULL DEFAULT TRUE
);

CREATE TABLE "Career" ( 
	"idCareer" SERIAL PRIMARY KEY, 
	"name" varchar(50) NOT NULL , 
	"duration" varchar(20) NOT NULL , 
	"description" varchar(20) NOT NULL , 
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Objective" (    
	"idObjective" SERIAL PRIMARY KEY,
	"objetivename" varchar(50) NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Typeposition" (    
	"idTypePosition" SERIAL PRIMARY KEY,
	"level" varchar(50) NOT NULL,
	"typepositionname" varchar(50) NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Proof"(
	"idProof" SERIAL PRIMARY KEY,
	"date" date NOT NULL,
	"reason" varchar(50) NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Purpose"
(   
	"idPurpose" SERIAL PRIMARY KEY,
	"investigation" varchar(50) NOT NULL,
	"purposename" varchar(50) NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Sector" 
(  
	"idSector" SERIAL PRIMARY KEY,
	"sectorname" varchar(30) NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Subject"
(   
	"idSubject" SERIAL PRIMARY KEY,
	"name" varchar(50) NOT NULL,
	"credit" varchar(30) NOT NULL,
	"unit" varchar(50) NOT NULL,
	"characteristic" varchar(50) NOT NULL,
	"keyMatter" varchar(50) NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Territory"
(   
	"idTerritory" SERIAL PRIMARY KEY,
	"territoryname" varchar(50) NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Zone" (
	"idZone" SERIAL PRIMARY KEY,
	"zonename" varchar(30) NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Company" (
	"idCompany" SERIAL PRIMARY KEY,
	"name" varchar(50) NOT NULL,
	"email" varchar(50) NOT NULL,
	"phone" char(10) NOT NULL,
	"address" varchar(50) NOT NULL,
	"identificationNumber" varchar(50) NOT NULL,
	"idSector" INT NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Employee" (
	"idEmployee" SERIAL PRIMARY KEY,
	"name" varchar(50) NOT NULL,
	"lastname" varchar (50) NOT NULL,
	"mothersLastName" varchar(50) NOT NULL,
	"gender" varchar(50) NOT NULL,
	"phone" char(10) NOT NULL,
	"email" varchar(50) NOT NULL,
	"address" varchar(100) NOT NULL, 
	"socialSecurity" char(11) NOT NULL,
	"dateOfHire" date NOT NULL,
	"idSubject" INT NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Student"
(   
	"idStudent" SERIAL PRIMARY KEY,
	"name" varchar(50) NOT NULL,
	"lastName" varchar(50) NOT NULL,
	"mothersthestName" varchar(50) NOT NULL,
	"enrollment" varchar(50) NOT NULL,
	"birthdate" date NOT NULL,
	"curp" char (18) NOT NULL,
	"phone" char (10) NOT NULL,
	"rfc" char (13) NOT NULL,
	"socialSegurity" char (11) NOT NULL,
	"idEmployee" INT NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Visit"
(
	"idVisit" SERIAL PRIMARY KEY,
	"numberofstudent" INT NOT NULL, 
	"duration" varchar(50) NOT NULL, 
	"objetive" varchar(100) NOT NULL ,
	"aplicacion" date NOT NULL, 
	"datevisit" date NOT NULL,
	"requiretransportation" varchar(10) NOT NULL ,
	"result" varchar(150) NOT NULL ,
	"idCompany" INT NOT NULL ,
	"idZone" INT NOT NULL,
	"idEmployee" INT NOT NULL,
	"idStudent" INT NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Activity" 
(    
	"idActivity" SERIAL PRIMARY KEY,
	"activityname" varchar(50) NOT NULL, 
	"status" boolean NOT NULL DEFAULT TRUE,
	"idStudent"  INT NOT NULL,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Agreement" (
	"idAgreement" SERIAL PRIMARY KEY,
	"acronym" varchar(50) NOT NULL,
	"objetive" varchar(25) NOT NULL,
	"idObjetive" INT NOT NULL,
	"idTerritory" INT NOT NULL,
	"statusAgreement" varchar(50) NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Empreneur"(
	"idEmpreneur" SERIAL PRIMARY KEY,
	"request" varchar(50) NOT NULL,
	"objetive" varchar(50) NOT NULL,
	"codeOfEmpreneur" varchar(50) NOT NULL,
	"workteam" varchar(50) NOT NULL,
	"startdate" date NOT NULL,
	"finaldate" date NOT NULL,
	"duration" varchar(50) NOT NULL,
	"idEmployee" INT NOT NULL,
	"idStudent" INT NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "Viatic"
(    
	"idViatic" SERIAL PRIMARY KEY,
	"place" varchar(200) NOT NULL,
	"description" varchar(250) NOT NULL,
	"amount" decimal (10,2) NOT NULL,
	"idEmployee" INT NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "CompanyStudent" (
	"IdCompanyStudent" SERIAL PRIMARY KEY,
	"date" Date NULL,
	"workplace" varchar(50) NOT NULL,
	"idStudent" INT NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUserCreate" INT NOT NULL,
	"dateCreate" DATE NOT NULL,
	"idUserModified" INT NOT NULL,
	"dateModified" DATE NOT NULL
);

CREATE TABLE "OfficeRequestcommission" 
(    
	"idOfficeRequestcommission" SERIAL PRIMARY KEY,
	"addressee" varchar(50) NOT NULL, 
	"header" varchar(50) NOT NULL, 
	"afftair" varchar(150) NOT NULL, 
	"date" date NOT NULL, 
	"status" boolean NOT NULL DEFAULT TRUE,
	"idEmploye" INT NOT NULL, 
	"IdUserCreate" INT NULL, 
	"creationdate" date NULL, 
	"IdUserModify" INT NULL, 
	"modified" date NULL 
);

CREATE TABLE "Position" 
(    
	"idPosition" SERIAL PRIMARY KEY,
	"jobDescription" varchar(50) NOT NULL, 
	"wage" varchar(50) NOT NULL, 
	"workingHours" varchar(50) NOT NULL, 
	"status" boolean NOT NULL DEFAULT TRUE,
	"idTypePosition" INT NOT NULL, 
	"IdUserCreate" INT NULL, 
	"creationdate" date NULL, 
	"IdUserModify" INT NULL, 
	"modified" date NULL 
);

CREATE TABLE "StudyPlan" 
(    
	"idStudyPlan" SERIAL PRIMARY KEY,
	"objetive" varchar(50) NOT NULL, 
	"starDate" date NOT NULL, 
	"finalDate" date NOT NULL, 
	"key" varchar(50) NOT NULL, 
	"status" boolean NOT NULL DEFAULT TRUE,
	"idCareer" INT NOT NULL, 
	"IdUserCreate" INT NULL, 
	"creationdate" date NULL, 
	"IdUserModify" INT NULL, 
	"modified" date NULL 
);

CREATE TABLE "ActivityCompany" 
(
	"idActivityCompany" SERIAL PRIMARY KEY,
	"idActivity" INT NOT NULL,
	"IdCompany" INT NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUsercreate" INT NULL,
	"datecreate" date NULL,
	"idusermodified" INT NULL, 
	"datemodified" date NULL
);

CREATE TABLE "AgreementCompany" 
(
	"idAgreementCompany" SERIAL PRIMARY KEY,
	"idAgreement" INT NOT NULL, 
	"IdCompany" INT NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUsercreate" INT NULL, 
	"datecreate" date NULL, 
	"idusermodified" INT NULL, 
	"datemodified" date NULL 
);

CREATE TABLE "AgreementPurpose"
(
	"idAgreementPurpose" SERIAL PRIMARY KEY,
	"idAgreement" INT NOT NULL, 
	"IdPurpose" INT NOT NULL,
	"status" boolean NOT NULL DEFAULT TRUE,
	"idUsercreate" INT NULL, 
	"datecreate" date NULL, 
	"idusermodified" INT NULL, 
	"datemodified" date NULL 
);

CREATE TABLE "EmployeePosition" 
(    
	"idEmployeePosition" SERIAL PRIMARY KEY,
	"IdEmployee" INT NOT NULL, 
	"IdPosition" INT NOT NULL, 
	"status" boolean NOT NULL DEFAULT TRUE,
	"idusercreate" INT NULL, 
	"datecreate" date NULL, 
	"idusermodified" INT NULL, 
	"datemodified" date NULL 
);

CREATE TABLE "SubjectStudyPlan" 
(    
	"idSubjectStudyPlan" SERIAL PRIMARY KEY,
	"IdSubject" INT NOT NULL, 
	"IdStudyPlan" INT NOT NULL, 
	"status" boolean NOT NULL DEFAULT TRUE,
	"idusercreate" INT NULL, 
	"datecreate" date NULL, 
	"idusermodified" INT NULL, 
	"datemodified" date NULL 
);


CREATE INDEX IX_Activity ON "Activity"("idActivity");
CREATE INDEX IX_Agreement ON "Agreement"("idAgreement");
CREATE INDEX IX_Career ON "Career"("idCareer");
CREATE INDEX IX_Company ON "Company"("idCompany");
CREATE INDEX IX_CompanyStudent ON "CompanyStudent"("idCompanyStudent");
CREATE INDEX IX_Employee ON "Employee"("idEmployee");
CREATE INDEX IX_Entrepreneur ON "Empreneur"("idEmpreneur");
CREATE INDEX IX_Objective ON "Objective"("idObjective");
CREATE INDEX IX_OfficeRequestcommission ON "OfficeRequestcommission"("idOfficeRequestcommission");
CREATE INDEX IX_Position ON "Position"("idPosition");
CREATE INDEX IX_TypePosition ON "Typeposition"("idTypePosition");
CREATE INDEX IX_Proof ON "Proof"("idProof");
CREATE INDEX IX_Purpose ON "Purpose"("idPurpose");
CREATE INDEX IX_Sector ON "Sector"("idSector");
CREATE INDEX IX_Student ON "Student"("idStudent");
CREATE INDEX IX_StudyPlan ON "StudyPlan"("idStudyPlan");
CREATE INDEX IX_Subject ON "Subject"("idSubject");
CREATE INDEX IX_Territory ON "Territory"("idTerritory");
CREATE INDEX IX_User ON "User"("idUser");
CREATE INDEX IX_Viatic ON "Viatic"("idViatic");
CREATE INDEX IX_Visit ON "Visit"("idVisit");
CREATE INDEX IX_Zone ON "Zone"("idZone");
CREATE INDEX IX_ActivityCompany ON "ActivityCompany"("idActivityCompany");
CREATE INDEX IX_AgreementCompany ON "AgreementCompany"("idAgreementCompany");
CREATE INDEX IX_AgreementPurpose ON "AgreementPurpose"("idAgreementPurpose");
CREATE INDEX IX_EmployePosition ON "EmployeePosition"("idEmployeePosition");
CREATE INDEX IX_SubjectStudyPlan ON "SubjectStudyPlan"("idSubjectStudyPlan");

ALTER TABLE "Career"
ADD CONSTRAINT FK_UserCreateCareer FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Career"
ADD CONSTRAINT FK_UserModifiedCareer FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "Objective"
ADD CONSTRAINT FK_UserCreateObjective FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Objective"
ADD CONSTRAINT FK_UserModifiedObjective FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "Typeposition"
ADD CONSTRAINT FK_UserCreateTypePosition FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Typeposition"
ADD CONSTRAINT FK_UserModifiedTypePosition FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");


ALTER TABLE "Activity"
ADD CONSTRAINT FK_UserCreateActivity FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Activity"
ADD CONSTRAINT FK_UserModifiedActivity FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "Student"
ADD CONSTRAINT FK_UserCreateStudent FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Student"
ADD CONSTRAINT FK_UserModifiedStudent FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "Agreement"idUserCreate
ADD CONSTRAINT FK_UserCreateAgreement FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Agreement"
ADD CONSTRAINT FK_UserModifiedAgreement FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "Employee"
ADD CONSTRAINT FK_UserCreateEmployee FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Employee"
ADD CONSTRAINT FK_UserModifiedEmployee FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "Empreneur"
ADD CONSTRAINT FK_UserCreateEmpreneur FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Empreneur"
ADD CONSTRAINT FK_UserModifiedEmpreneur FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");


ALTER TABLE "Company"
ADD CONSTRAINT FK_UserCreateCompany FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Company"
ADD CONSTRAINT FK_UserModifiedCompany FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "CompanyStudent"
ADD CONSTRAINT FK_UserCreateCompanyStudent FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "CompanyStudent"
ADD CONSTRAINT FK_UserModifiedCompanyStudent FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "Proof"
ADD CONSTRAINT FK_UserCreateProof FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Proof"
ADD CONSTRAINT FK_UserModifiedProof FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "Subject"
ADD CONSTRAINT FK_UserCreateSubject FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Subject"
ADD CONSTRAINT FK_UserModifiedSubject FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "OfficeRequestcommission"
ADD CONSTRAINT FK_UserCreateOfficeRequestcommission FOREIGN KEY ("IdUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "OfficeRequestcommission"
ADD CONSTRAINT FK_UserModifiedOfficeRequestcommission FOREIGN KEY ("IdUserModify")
REFERENCES "User"("idUser");

ALTER TABLE "StudyPlan"
ADD CONSTRAINT FK_UserCreateStudyPlan FOREIGN KEY ("IdUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "StudyPlan"
ADD CONSTRAINT FK_UserModifiedStudyPlan FOREIGN KEY ("IdUserModify")
REFERENCES "User"("idUser");

ALTER TABLE "Purpose"
ADD CONSTRAINT FK_UserCreatePurpose FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Purpose"
ADD CONSTRAINT FK_UserModifiedPurpose FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "Position"
ADD CONSTRAINT FK_UserCreatePosition FOREIGN KEY ("IdUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Position"
ADD CONSTRAINT FK_UserModifiedPosition FOREIGN KEY ("IdUserModify")
REFERENCES "User"("idUser");

ALTER TABLE "Sector"
ADD CONSTRAINT FK_UserCreateSector FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Sector"
ADD CONSTRAINT FK_UserModifiedSector FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "Territory"
ADD CONSTRAINT FK_UserCreateTerritory FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Territory"
ADD CONSTRAINT FK_UserModifiedTerritory FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "Viatic"
ADD CONSTRAINT FK_UserCreateViatic FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Viatic"
ADD CONSTRAINT FK_UserModifiedViatic FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "Visit"
ADD CONSTRAINT FK_UserCreateVisit FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Visit"
ADD CONSTRAINT FK_UserModifiedVisit FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "Zone"
ADD CONSTRAINT FK_UserCreateZone FOREIGN KEY ("idUserCreate")
REFERENCES "User"("idUser");

ALTER TABLE "Zone"
ADD CONSTRAINT FK_UserModifiedZone FOREIGN KEY ("idUserModified")
REFERENCES "User"("idUser");

ALTER TABLE "ActivityCompany"
ADD CONSTRAINT FK_UserCreateActivityCompany FOREIGN KEY ("idUsercreate")
REFERENCES "User"("idUser");

ALTER TABLE "ActivityCompany"
ADD CONSTRAINT FK_UserModifiedActivityCompany FOREIGN KEY ("idusermodified")
REFERENCES "User"("idUser");

ALTER TABLE "AgreementCompany"
ADD CONSTRAINT FK_UserCreateAgreementCompany FOREIGN KEY ("idUsercreate")
REFERENCES "User"("idUser");

ALTER TABLE "AgreementCompany"
ADD CONSTRAINT FK_UserModifiedAgreementCompany FOREIGN KEY ("idusermodified")
REFERENCES "User"("idUser");

ALTER TABLE "AgreementPurpose"
ADD CONSTRAINT FK_UserCreateAgreementPurpose FOREIGN KEY ("idUsercreate")
REFERENCES "User"("idUser");

ALTER TABLE "AgreementPurpose"
ADD CONSTRAINT FK_UserModifiedAgreementPurpose FOREIGN KEY ("idusermodified")
REFERENCES "User"("idUser");

ALTER TABLE "EmployeePosition"
ADD CONSTRAINT FK_UserCreateEmployeePosition FOREIGN KEY ("idusercreate")
REFERENCES "User"("idUser");

ALTER TABLE "EmployeePosition"
ADD CONSTRAINT FK_UserModifiedEmployeePosition FOREIGN KEY ("idusermodified")
REFERENCES "User"("idUser");

ALTER TABLE "SubjectStudyPlan"
ADD CONSTRAINT FK_UserCreateSubjectStudyPlan FOREIGN KEY ("idusercreate")
REFERENCES "User"("idUser");

ALTER TABLE "SubjectStudyPlan"
ADD CONSTRAINT FK_UserModifiedSubjectStudyPlan FOREIGN KEY ("idusermodified")
REFERENCES "User"("idUser");

ALTER TABLE "Activity"
ADD CONSTRAINT FK_ActivityStudent FOREIGN KEY ("idStudent")
REFERENCES "Student"("idStudent");

ALTER TABLE "Student"
ADD CONSTRAINT FK_StudentEmployee FOREIGN KEY ("idEmployee")
REFERENCES "Employee"("idEmployee");

ALTER TABLE "Agreement"
ADD CONSTRAINT FK_AgreementObjective FOREIGN KEY ("idObjetive")
REFERENCES "Objective" ("idObjective");

ALTER TABLE "Agreement"
ADD CONSTRAINT FK_AgreementTerritory FOREIGN KEY ("idTerritory")
REFERENCES "Territory" ("idTerritory");

ALTER TABLE "Employee"
ADD CONSTRAINT FK_AgreementSubject FOREIGN KEY ("idSubject")
REFERENCES "Subject" ("idSubject");





INSERT INTO "User" ("name","password", "email")
VALUES ('Nallely', '130218','toledo@');

INSERT INTO "Career"("name","duration","description","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES('Informatica', '4 años 9 meses','Programacion',1,NOW(),1,NOW()),
      ('Mecanica', '4 años 9 meses','Automotriz',1,NOW(),1,NOW()),
	  ('Gestion Empresarial', '4 años 9 meses','Gestiona',1,NOW(),1,NOW()),
	  ('Electronica', '4 años 9 meses','Gestiona',1,NOW(),1,NOW()),
	  ('Energias Renovables', '4 años 9 meses','Medio ambiente',1,NOW(),1,NOW()),
	  ('Industrial', '4 años 9 meses','Industria',1,NOW(),1,NOW());

INSERT INTO "Objective" ("objetivename","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES  ('specific',1,NOW(),1,NOW()),
		('general',1,NOW(),1,NOW());
		

INSERT INTO "Typeposition"("level","typepositionname","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES('intermedio', 'technicalAnalyst',1,NOW(),1,NOW()),
      ('intermedio', 'teacher',1,NOW(),1,NOW()),
	  ('intermedio', 'divisionChief',1,NOW(),1,NOW()),
	  ('intermedio', 'holderofthetransparencyUnit',1,NOW(),1,NOW()),
	    ('intermedio', 'headofDepartment',1,NOW(),1,NOW());

INSERT INTO "Proof"("date","reason","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES  ('2023-01-23','Visita a denso',1,NOW(),1,NOW()),
        ('2023-01-23','Visita a ahmsa',1,NOW(),1,NOW()),
		('2023-01-23','Visita a metro rey',1,NOW(),1,NOW()),
		('2023-01-23','Visita a wittur',1,NOW(),1,NOW()),
		('2023-01-23','Visita a ferromex',1,NOW(),1,NOW());

INSERT INTO "Purpose"("purposename","investigation","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES  ('investigation','investigation',1,NOW(),1,NOW()),
        ('practice','practice',1,NOW(),1,NOW()),
		('resindence','resindence',1,NOW(),1,NOW()),
		('socialService','socialService',1,NOW(),1,NOW()),
		('external','external',1,NOW(),1,NOW());

INSERT INTO "Sector"("sectorname","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES  ('public',1,NOW(),1,NOW()),
        ('private',1,NOW(),1,NOW()),
		('service',1,NOW(),1,NOW()),
		('social',1,NOW(),1,NOW()),
			('productive',1,NOW(),1,NOW()),
		('educative',1,NOW(),1,NOW());

INSERT INTO "Subject"("name","credit","unit","characteristic","keyMatter","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES ('ingles','100','1','Actividad 1','0923',1,NOW(),1,NOW()),
       ('ingles','100','2','Actividad 2','0923',1,NOW(),1,NOW()),
	   ('ingles','100','3','Actividad 3','0923',1,NOW(),1,NOW()),
	   ('ingles','100','4','Actividad 4','0923',1,NOW(),1,NOW()),
	   ('ingles','100','5','Actividad 5','0923',1,NOW(),1,NOW());

INSERT INTO "Territory"("territoryname","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES  ('nacional',1,NOW(),1,NOW()),
        ('internacional',1,NOW(),1,NOW());
	

INSERT INTO "Zone"("zonename","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES('regional',1,NOW(),1,NOW()),
      ('local',1,NOW(),1,NOW()),
	  ('national',1,NOW(),1,NOW());
	 

INSERt INTO "Company"("name","email","phone","address","identificationNumber","idSector","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES('Altos hornos de mexico','hornos@gmail.com','8661652344','kenedy 122 monclova','2023',1,1,NOW(),1,NOW()),
      ('Denso','denso@gmail.com','8661302344','de los hornos cd frontera','2023',2,1,NOW(),1,NOW()),
	  ('Ferromex','ferromex@gmail.com','8661623445','Americana cd frontera','2023',3,1,NOW(),1,NOW()),
	  ('Coahuila Durango','coahuiladurango@gmail.com','8662002344','porfirio diaz cd frontera','2023',4,1,NOW(),1,NOW()),
	  ('Aptiv','aptiv@gmail.com','8661702344','lib carlos salinas de gortari','2023',5,1,NOW(),1,NOW());

INSERT INTO "Employee"("name","lastname","mothersLastName","gender","phone","email","address","socialSecurity","dateOfHire","idSubject","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES ('Luis Alfonso','Rodriguez','Perez','Hombre','8662567822','luis@gmail.com','Ayuntamiento 212 Occidental','44180032044','2023-01-23',1,1,NOW(),1,NOW()),
       ('Alberto','Salazar','Zuñiga','Hombre','8662347822','alberto@gmail.com','Ignacio allende 313 La sierrita','44180032042','2023-02-12',2,1,NOW(),1,NOW()),
	   ('Antonio','Rodriguez','Tovar','Hombre','8661227822','antonio@gmail.com','Jalisco nte 1700 Monclova','44180032043','2023-02-10',3,1,NOW(),1,NOW()),
	   ('Gabriela','Mendoza','Aguilar','Mujer','8662137822','gabriela@gmail.com','C. Monaco 1010 Monclova','44180032044','2023-04-11',4,1,NOW(),1,NOW()),
	   ('Patricia','Hernendez','Mata','Mujer','8665437822','patricia@gmail.com','C. Zaragoza 227 Frontera','44180032045','2023-07-25',5,1,NOW(),1,NOW());

INSERT INTO "Student" ("name","lastName","mothersthestName","enrollment","birthdate","curp","phone","rfc","socialSegurity","idEmployee","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES ('Nallely','Toledo','Alonso','I15171917','1996-06-09','TOASMNL000NLLN9654','8667882323','TOASMNL000NLL','44180032043',1,1,NOW(),1,NOW()),
       ('Alberto','Salazar','Zuñiga','I18050517','2000-04-08','SAZA000408HCLLXLA6','8661222321','SAZA000408K61','44180032089',2,1,NOW(),1,NOW()),
	   ('Antonio','Perez','Gaitan','I23050517','2003-08-20','PEGA030820HCLLXKLR','8664322321','PEGA030820HCL','44180032090',3,1,NOW(),1,NOW()),
	   ('Maria','Rivera','Soledad','I20050517','2005-01-25','RISM000408HCLLXLA6','8662332321','RISM000408HCL','44180032011',4,1,NOW(),1,NOW()),
	   ('Bertha','Ibarra','Vazquez','I17050517','2007-09-17','VAVB000408HCLLXLO6','8666542321','VAVB000408HCL','44180032055',5,1,NOW(),1,NOW());
	   
INSERT INTO "Visit"("numberofstudent","duration","objetive","aplicacion","datevisit","requiretransportation","result","idCompany","idZone","idEmployee","idStudent","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES ('23','3 Horas','Conocer las instalaciones','2023-09-17','2023-09-17','Si','Excelente',1,1,1,1,1,NOW(),1,NOW()),
       ('10','2 Horas','Conocer las instalaciones','2023-10-09','2023-10-09','No','Excelente',2,2,2,2,1,NOW(),1,NOW()),
	   ('50','8 Horas','Conocer las instalaciones','2023-10-05','2023-10-05','Si','Excelente',3,3,3,3,1,NOW(),1,NOW()),
	   ('32','3 Horas','Conocer las instalaciones','2023-11-23','2023-11-23','Si','Excelente',4,4,4,4,1,NOW(),1,NOW()),
	   ('27','3 Horas','Conocer las instalaciones','2023-12-01','2023-12-01','Si','Excelente',5,5,5,5,1,NOW(),1,NOW());

INSERT INTO "Activity"("activityname","idStudent","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES('practice',1,1,NOW(),1,NOW()),
      ('residence ',2,1,NOW(),1,NOW()),
	  ('stay',3,1,NOW(),1,NOW()),
      ('socialservice',4,1,NOW(),1,NOW());
  
INSERT INTO "Agreement"("acronym","objetive","idObjetive","idTerritory","statusAgreement","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES ('CFE','Servicio',1,1,'Activo',1,NOW(),1,NOW()),
       ('Simas','Servicio',2,2,'Inactivo',1,NOW(),1,NOW()),
	   ('Telmex','Servicio',1,2,'Activo',1,NOW(),1,NOW()),
	   ('Transporte','Servicio',2,1,'Activo',1,NOW(),1,NOW()),
	   ('Mantenimiento','Servicio',1,2,'Inactivo',1,NOW(),1,NOW());

INSERt INTO "Empreneur"("request" ,"objetive","codeOfEmpreneur" ,"workteam" ,"startdate" ,"finaldate" ,"duration" ,"idEmployee" ,"idStudent","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES('Solicitud de Proyecto 1','Investigacion sobre Redes ','A20230412 ','4','2023-09-17','2023-09-17','6 Meses',1,1,1,NOW(),1,NOW()),
      ('Solicitud de Proyecto 2','Investigacion de campo ','A20230923 ','2','2023-09-17','2023-09-17','6 Meses',1,1,1,NOW(),1,NOW()),
	  ('Solicitud de Proyecto 3','Exposicion','A20231131 ','5','2023-09-17','2023-09-17','6 Meses',1,1,1,NOW(),1,NOW()),
	  ('Solicitud de Proyecto 4','Test','A20231002 ','2','2023-09-17','2023-09-17','6 Meses',1,1,1,NOW(),1,NOW()),
	  ('Solicitud de Proyecto 5','Exposicion','A20232528 ','3','2023-09-17','2023-09-17','6 Meses',1,1,1,NOW(),1,NOW());

INSERT INTO "Viatic"("place","description","amount","idEmployee","idUserCreate","dateCreate","idUserModify","dateModified")
VALUES ('Saltillo Coahuila','Realizar una visita para conocer las instalaciones y que es lo que realizan.','2500.50',1,1,NOW(),1,NOW()),
       ('Monterrey Nuevo Leon','Realizar una visita para conocer las instalaciones y que es lo que realizan.','3289.50',2,1,NOW(),1,NOW()),
	   ('Monclova Coahuila','Realizar una visita para conocer las instalaciones y que es lo que realizan.','1289.50',3,1,NOW(),1,NOW()),
	   ('Frontera Coahuila','Realizar una visita para conocer las instalaciones y que es lo que realizan.','1392.50',4,1,NOW(),1,NOW()),
	   ('Saltillo Coahuila','Realizar una visita para conocer las instalaciones y que es lo que realizan.','3478.50',5,1,NOW(),1,NOW());

INSERT INTO "CompanyStudent" ("date","workplace","idStudent","idUserCreate","dateCreate","idUserModified","dateModified")
VALUES ('2023-10-23','HFI',1,1,NOW(),1,NOW()),
       ('2023-11-30','Grupo Fox',2,1,NOW(),1,NOW()),
	   ('2023-09-25','Denso',3,1,NOW(),1,NOW()),
	   ('2023-10-02','Aramak',4,1,NOW(),1,NOW()),
	   ('2023-11-09','Quality',5,1,NOW(),1,NOW());

INSERT INTO "OfficeRequestcommission" ("addressee" ,"header" ,"afftair" ,"date" ,"idEmploye","IdUserCreate","creationdate","IdUserModify","modified")
VALUES ('Luis Alfonso Rodriguez Perez','Realizar Visita','Ir a las instalaciones y hacer una reunion','2023-11-09',1,1,NOW(),1,NOW()),
       ('Alberto Salazar Zuñiga', 'Revisión de Contrato', 'Reunión para revisar contrato', '2023-11-10',2, 1, NOW(), 1, NOW()),
       ('Antonio Rodriguez Tovar', 'Informe Mensual', 'Preparar informe de ventas', '2023-11-11', 3,1, NOW(), 1, NOW()),
       ('Gabriela Mendoza Aguilar', 'Entrevista de Trabajo', 'Realizar entrevista con candidato', '2023-11-12',4, 1, NOW(), 1, NOW()),
       ('Patricia Hernendez Mata', 'Reunión de Equipo', 'Planificar estrategia de equipo', '2023-11-13',5, 1, NOW(), 1, NOW()); 

INSERT INTO "Position"( "jobDescription", "wage", "workingHours" ,"idTypePosition" ,"IdUserCreate","creationdate","IdUserModify","modified")
VALUES ('Jefe de maestros','3210.99','8 Horas',1,1,NOW(),1,NOW()),
        ('Profesor de Matemáticas', '2500.00', '8 Horas', 2, 1, NOW(), 1, NOW()),
       ('Director', '4800.00', '8 Horas', 3, 1, NOW(), 1, NOW()),
       ('Psicologo/a', '2800.00', '8 Horas', 4, 1, NOW(), 1, NOW()),
       ('Subdirector', '2200.00', '8 Horas', 5, 1, NOW(), 1, NOW());

INSERT INTO "StudyPlan"("objetive","starDate","finalDate","key" ,"idCareer"  ,"IdUserCreate","creationdate","IdUserModify","modified")
VALUES ('Informatica','2023-11-12','2023-11-12','I1920812',1,1,NOW(),1,NOW()),
       ('Gestion Empresarial','2023-11-07','2023-11-12','G8237288',2,1,NOW(),1,NOW()),
	   ('Electronica','2023-11-23','2023-11-12','E1920812',3,1,NOW(),1,NOW()),
       ('Mecanica','2023-10-31','2023-11-12','M765647',4,1,NOW(),1,NOW()),
	   ('Industrial','2023-09-12','2023-11-12','IN99087Y',5,1,NOW(),1,NOW());

INSERT INTO "ActivityCompany"("idActivity","IdCompany" ,"idUsercreate","datecreate","idusermodified","datemodified")
Values (1,1,1,NOW(),1,NOW()),
       (2,2,1,NOW(),1,NOW()),
	   (3,3,1,NOW(),1,NOW()),
	   (4,4,1,NOW(),1,NOW()),
	   (5,5,1,NOW(),1,NOW());

INSERT INTO "AgreementCompany"("idAgreement","IdCompany" ,"idUsercreate","datecreate","idusermodified","datemodified")
Values (1,1,1,NOW(),1,NOW()),
       (2,2,1,NOW(),1,NOW()),
	   (3,3,1,NOW(),1,NOW()),
	   (4,4,1,NOW(),1,NOW()),
	   (5,5,1,NOW(),1,NOW());

INSERT INTO "AgreementPurpose"("idAgreement","IdPurpose" ,"idUsercreate","datecreate","idusermodified","datemodified")
Values (1,1,1,NOW(),1,NOW()),
       (2,2,1,NOW(),1,NOW()),
	   (3,3,1,NOW(),1,NOW()),
	   (4,4,1,NOW(),1,NOW()),
	   (5,5,1,NOW(),1,NOW());

INSERT INTO "EmployeePosition"("IdEmployee","IdPosition" ,"idusercreate","datecreate","idusermodified","datemodified")
Values (1,1,1,NOW(),1,NOW()),
       (2,2,1,NOW(),1,NOW()),
	   (3,3,1,NOW(),1,NOW()),
	   (4,4,1,NOW(),1,NOW()),
	   (5,5,1,NOW(),1,NOW());

INSERT INTO "SubjectStudyPlan"("IdSubject","IdStudyPlan" ,"idusercreate","datecreate","idusermodified","datemodified")
Values (1,1,1,NOW(),1,NOW()),
       (2,2,1,NOW(),1,NOW()),
	   (3,3,1,NOW(),1,NOW()),
	   (4,4,1,NOW(),1,NOW()),
	   (5,5,1,NOW(),1,NOW());