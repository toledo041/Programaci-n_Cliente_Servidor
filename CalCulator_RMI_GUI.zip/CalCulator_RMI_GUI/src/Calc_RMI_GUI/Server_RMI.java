
package Calc_RMI_GUI;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;


public class Server_RMI {
    public static void main(String[] args) {
        try {
            Registry reg = LocateRegistry.createRegistry(1098);
            Calc_Interface_Impliment cl = new Calc_Interface_Impliment();
            reg.rebind("CalSurvices", cl);
            System.out.println("Server iniciando ...");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
}
