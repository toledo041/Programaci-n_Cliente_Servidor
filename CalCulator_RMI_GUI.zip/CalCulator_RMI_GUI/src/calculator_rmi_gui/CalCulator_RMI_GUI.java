
package calculator_rmi_gui;


public class CalCulator_RMI_GUI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
