<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta de Libros</title>
</head>
<body>

<h1>Listado de Libros</h1>
<button id="btnConsultar">Consultar Libros</button>
<table id="tablaLibros" border="1">
    <thead>
        <tr>
            <th>ID</th>
            <th>Título</th>
            <th>Autor</th>
        </tr>
    </thead>
    <tbody id="cuerpoTablaLibros"></tbody>
</table>

<script>
// Función para realizar la solicitud al servicio web y actualizar la tabla
function consultarLibros() {
    // Realizar una solicitud GET al servicio web de libros
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "http://localhost/tarea5/practica.php", true);
    xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // Parsear la respuesta JSON
            var libros = JSON.parse(xhr.responseText);

            // Limpiar la tabla antes de agregar nuevos datos
            document.getElementById("cuerpoTablaLibros").innerHTML = "";

            // Agregar datos a la tabla
            libros.forEach(function(libro) {
                var row = document.createElement("tr");
                var idCell = document.createElement("td");
                var tituloCell = document.createElement("td");
                var autorCell = document.createElement("td");

                idCell.textContent = libro.id;
                tituloCell.textContent = libro.titulo;
                autorCell.textContent = libro.autor;

                row.appendChild(idCell);
                row.appendChild(tituloCell);
                row.appendChild(autorCell);

                document.getElementById("cuerpoTablaLibros").appendChild(row);
            });
        }
    };
    xhr.send();
}

// Asociar la función al evento click del botón
document.getElementById("btnConsultar").addEventListener("click", consultarLibros);
</script>

</body>
</html>
