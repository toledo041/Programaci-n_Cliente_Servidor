<?php

// Permitir el acceso desde cualquier dominio (CORS)
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");



// Datos simulados de libros
$libros = array(
    array("id" => 1, "titulo" => "Libro 1", "autor" => "Autor 1"),
    array("id" => 2, "titulo" => "Libro 2", "autor" => "Autor 2"),
    array("id" => 3, "titulo" => "Libro 3", "autor" => "Autor 3")
);

// Verificar el tipo de solicitud
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Si es una solicitud GET, devolver la lista de libros en formato JSON
    echo json_encode($libros);
} else {
    // Devolver un código de estado 405 (Método no permitido) si la solicitud no es GET
    http_response_code(405);
    echo json_encode(array("mensaje" => "Método no permitido"));
}
?>
