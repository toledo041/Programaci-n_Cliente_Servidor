﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrudCSharp.Logica
{
    public class EmpleadoLogica
    {
        //private static string cadena =  
    }
}
