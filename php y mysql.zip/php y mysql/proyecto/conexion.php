<?php
$servername = "localhost";
$username = "root";
$password = "A123456789.";
$dbname = "vinculation";
?>